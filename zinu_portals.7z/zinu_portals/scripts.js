document.addEventListener("DOMContentLoaded", () => {
    const images = document.querySelectorAll(".carousel-images .image");
    const dots = document.querySelectorAll(".dots .dot");
    const leftArrow = document.querySelector(".arrow.left");
    const rightArrow = document.querySelector(".arrow.right");
    const carouselImages = document.querySelector(".carousel-images");
    let currentIndex = 0;

    const updateCarousel = () => {
        const offset = -currentIndex * 100; // Pārvietot karuseli uz attiecīgo pocīziju
        carouselImages.style.transform = `translateX(${offset}%)`; // Priekš pludenām un vienmērīgām animācijām kad pārslēdzas starp karuseļa bildēm

        // Atjaunot "punktiņus" katru reizi kad pabīdas karuselis
        dots.forEach((dot, index) => {
            dot.classList.toggle("active", index === currentIndex);
        });
    };
		//Karuseļa kustība uz nākamo pozīciju
    const moveToNextSlide = () => {
        currentIndex = (currentIndex + 1) % images.length; 
        updateCarousel();
    };
		//Karuseļa kustība uz iepriekšējo pozīciju
    const moveToPrevSlide = () => {
        currentIndex = (currentIndex - 1 + images.length) % images.length; 
        updateCarousel();
    };

    // Karuseļa "bultiņu" darbības funkcionalitāte
    rightArrow.addEventListener("click", moveToNextSlide);
    leftArrow.addEventListener("click", moveToPrevSlide);

    // Karuseļa "punktiņu" darbības funkcionlitāte
    dots.forEach((dot, index) => {
        dot.addEventListener("click", () => {
            currentIndex = index;
            updateCarousel();
        });
    });

    // Karuseļa inicializēšana
    updateCarousel();
});